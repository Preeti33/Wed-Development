import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { Technologies1RoutingModule } from './technologies1-routing.module';
import { TdemoComponent } from './tdemo/tdemo.component';


@NgModule({
  declarations: [
    TdemoComponent
  ],
  imports: [
    CommonModule,
    Technologies1RoutingModule
  ]
})
export class Technologies1Module { }
