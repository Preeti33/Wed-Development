import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tdemo',
  templateUrl: './tdemo.component.html',
  styleUrls: ['./tdemo.component.css']
})
export class TdemoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
