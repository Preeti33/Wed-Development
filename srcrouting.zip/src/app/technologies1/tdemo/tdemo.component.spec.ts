import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TdemoComponent } from './tdemo.component';

describe('TdemoComponent', () => {
  let component: TdemoComponent;
  let fixture: ComponentFixture<TdemoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TdemoComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TdemoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
