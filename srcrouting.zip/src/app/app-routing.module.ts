import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {path: 'technologies1',loadChildren : ()=>import('./technologies1/technologies1.module').then(m=>m.Technologies1Module)},
  {path: 'book1',loadChildren : ()=>import('./books1/books1-routing.module').then(m=>m.Books1RoutingModule)},
  {path: '',redirectTo:'',pathMatch : 'full'}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
