import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Demo2Component } from './demo2/demo2.component';
import { BdemoComponent } from './bdemo/bdemo.component';



@NgModule({
  declarations: [
    Demo2Component,
    BdemoComponent
  ],
  imports: [
    CommonModule
  ]
})
export class BooksModule { }
