import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { BdemoComponent } from './bdemo/bdemo.component';

const routes: Routes = [
  { path: '',component: BdemoComponent}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class Books1RoutingModule { }
