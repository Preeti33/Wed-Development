import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { Books1RoutingModule } from './books1-routing.module';
import { BdemoComponent } from './bdemo/bdemo.component';


@NgModule({
  declarations: [
    BdemoComponent
  ],
  imports: [
    CommonModule,
    Books1RoutingModule
  ]
})
export class Books1Module { }
