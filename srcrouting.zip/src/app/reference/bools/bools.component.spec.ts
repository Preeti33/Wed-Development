import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BoolsComponent } from './bools.component';

describe('BoolsComponent', () => {
  let component: BoolsComponent;
  let fixture: ComponentFixture<BoolsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BoolsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BoolsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
