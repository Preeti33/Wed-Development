import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bools',
  templateUrl: './bools.component.html',
  styleUrls: ['./bools.component.css']
})
export class BoolsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
