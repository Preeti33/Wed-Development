import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sdemo',
  templateUrl: './sdemo.component.html',
  styleUrls: ['./sdemo.component.css']
})
export class SdemoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
