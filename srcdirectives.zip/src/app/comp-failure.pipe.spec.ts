import { CompFailurePipe } from './comp-failure.pipe';

describe('CompFailurePipe', () => {
  it('create an instance', () => {
    const pipe = new CompFailurePipe();
    expect(pipe).toBeTruthy();
  });
});
