import { Directive, ElementRef } from '@angular/core';
import { Element } from '@angular/compiler';
import { HostListener } from '@angular/core';

@Directive({
  selector: '[appCompSuccess1]'
})
export class CompSuccess1Directive 
{
  constructor(private eeobj : ElementRef) { }

  @HostListener('mouseenter')onmouseenter()
  {
    this.eeobj.nativeElement.style.background = 'green';
  }

  @HostListener('mouseleave')onmouseleave()
  {
    this.eeobj.nativeElement.style.background = 'black';
  }

}
