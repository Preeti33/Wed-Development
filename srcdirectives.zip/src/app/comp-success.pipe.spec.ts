import { CompSuccessPipe } from './comp-success.pipe';

describe('CompSuccessPipe', () => {
  it('create an instance', () => {
    const pipe = new CompSuccessPipe();
    expect(pipe).toBeTruthy();
  });
});
