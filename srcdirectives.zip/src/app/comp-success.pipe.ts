import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'compSuccess'
})
export class CompSuccessPipe implements PipeTransform {

  transform(value: unknown, ...args: unknown[]): unknown {
    return null;
  }

}
