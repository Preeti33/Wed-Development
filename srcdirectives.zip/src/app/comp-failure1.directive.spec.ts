import { CompFailure1Directive } from './comp-failure1.directive';

describe('CompFailure1Directive', () => {
  it('should create an instance', () => {
    const directive = new CompFailure1Directive();
    expect(directive).toBeTruthy();
  });
});
