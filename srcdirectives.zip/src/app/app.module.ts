import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CompSuccessPipe } from './comp-success.pipe';
import { CompFailurePipe } from './comp-failure.pipe';
import { CompSuccess1Directive } from './comp-success1.directive';
import { CompFailure1Directive } from './comp-failure1.directive';

@NgModule({
  declarations: [
    AppComponent,
    CompSuccessPipe,
    CompFailurePipe,
    CompSuccess1Directive,
    CompFailure1Directive
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
