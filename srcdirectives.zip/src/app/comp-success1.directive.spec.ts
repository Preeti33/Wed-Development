import { CompSuccess1Directive } from './comp-success1.directive';

describe('CompSuccess1Directive', () => {
  it('should create an instance', () => {
    const directive = new CompSuccess1Directive();
    expect(directive).toBeTruthy();
  });
});
